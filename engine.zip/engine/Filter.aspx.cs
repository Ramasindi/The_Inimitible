﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectTest
{
    public partial class Filter : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void DropDownList1_SelectedIndexChanged1(object sender, EventArgs e)
        {
            if (DropDownList1 == null)
            {
                Label1.Text = "Please choose what you're studying";
            }
            else
            {
                Label1.Text = "Your study Choice is: " + DropDownList1.SelectedValue + ": Select the relevent image for best experience";
            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("PastPapers.aspx");
            // the question paper is not showing on my side please try that side
            // Response.Redirect("Accounting");
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("PastPapers.aspx");
            // the question paper is not showing on my side please try that side
            // Response.Redirect("Accounting");
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("PastPapers.aspx");
            // the question paper is not showing on my side please try that side
            // Response.Redirect("Accounting");
        }

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("PastPapers.aspx");
            // the question paper is not showing on my side please try that side
            // Response.Redirect("Accounting");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("TutorRegister.aspx");
        }

        protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("HomeworkHelper.aspx");
        }
    }
}